/**********MODAL PHOTO****/

// Get the modal
var modal = document.getElementById('myModal');

// Get the button that opens the modal
var btn = document.getElementById("myBtn");

// Get the <span> element that closes the modal
var span = document.getElementsByClassName("close")[0];

// When the user clicks on the button, open the modal 
btn.onclick = function () {
    modal.style.display = "block";
}

// When the user clicks on <span> (x), close the modal
span.onclick = function () {
    modal.style.display = "none";
}

// When the user clicks anywhere outside of the modal, close it
window.onclick = function (event) {
    if (event.target === modal) {
        modal.style.display = "none";
    }
}


/********* MORE MENTORS ***********/
var mentors=1;
var mentor_class = 'mentor';
var more_links;
var links;

var add_mentor = document.getElementById('more_mentors');

add_mentor.onclick = function() {
    mentors++;
    
    var more_links = 'more_links_'+mentors;
    var links = 'links_'+mentors;
    
    if(mentors%2 === 0){
        mentor_class = 'mentor2';
    } else {
        mentor_class = 'mentor';
    }
    
    
    $('#all_mentors').append('<div class="'+mentor_class+'"><!--Name--><p>Name</p><input type="text" name="mentor_name" placeholder="Name"><!--Photo--><p>Photo</p><button class="buttons" id="myBtn" type="button">Choose Photo</button><!--Function--><p>Function within the company</p><input type="text" name="mentor_function" placeholder="Designer"><!--Links--><p>Link <span class="more_links" id="'+more_links+'">+</span></p><div class="mentor_links" id="'+links+'" ><input type="text" name="mentor_link" placeholder="Website, Blog, LinkedIn, ..."></div></div>');
}

/********* MORE LINKS ***********/
/*
for (var m = 1; m <= mentors; m++){
    document.getElementById('more_links_'+m).onclick = function MoreLinks('links_'+m);
}


function MoreLinks( var div ){
    $('"'+div+'"').append('<input type="text" name="mentor_link" placeholder="Website, Blog, LinkedIn, ...">');
}
*/